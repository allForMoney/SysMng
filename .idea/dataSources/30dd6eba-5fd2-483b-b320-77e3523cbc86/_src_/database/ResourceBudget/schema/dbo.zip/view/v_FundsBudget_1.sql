
CREATE view [dbo].[v_FundsBudget_1]
as
 select c.UserID, MajorName,c.ID,ProjectNum,ProjectName as 资金来源,
      [MaterialMake]+[CompanyCase]+[CourseDevelopment]+[ToolSoftware]+[ApplicationPromote]+[ResearchProve]+[ExpertConsult]+[OtherFee] as 预算资金总额
      ,[MaterialMake] as 素材制作
      ,[CompanyCase] as 企业案例收集制作
      ,[CourseDevelopment] as 课程开发
      ,[ToolSoftware] as 特殊工具软件制作
      ,[ApplicationPromote] as 应用推广
      ,[ResearchProve] as 调研论证
      ,[ExpertConsult] as 专家咨询
      ,[OtherFee] as 其他
      ,[BudgetYear] as 预算年度 
 from   dbo.v_UserProject c left join dbo.FundsBudget a on c.UserID=a.UserID and  c.ID=a.PID and a.IsDelete=0
     and a.SubmitTime is not null

GO
