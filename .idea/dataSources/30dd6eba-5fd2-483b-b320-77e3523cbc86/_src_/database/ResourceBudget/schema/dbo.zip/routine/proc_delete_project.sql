
CREATE PROCEDURE [dbo].[proc_delete_project]
	@id int
AS
BEGIN
--删除一个项目
declare @userid int;
declare @projectno nvarchar(50);
select @userid = userid,@projectno=ProjectNo from Project where id=@id;
if @userid is null 
begin
	print 'null';
	RAISERROR (
             N'项目为空，id为 %d.', -- Message text,
             16,                        -- Severity,
             1,                         -- State,             
             @id                        -- First argument.
          ); 
end
else
begin	
delete from TestMsg where ProjectId=@id;
delete from BudgetImportDetail where budgetimportid in (
select id from BudgetImport where ProjectId=@id);
delete from BudgetImportDetail2016 where budgetimportid in (
select id from BudgetImport where ProjectId=@id);
delete from IndicatorImportDetail1 where budgetimportid in (
select id from BudgetImport where ProjectId=@id);
delete from IndicatorImportDetail2 where budgetimportid in (
select id from BudgetImport where ProjectId=@id);
delete from BudgetImport where ProjectId=@id;
delete from IndicatorObjective where ProjectId=@id;
delete from IndicatorReport where ProjectId=@id;
delete from report where ProjectId=@id;
delete from fundsbudget where userid=@userid;
delete from FundsIn where UserId =@userid;
delete from FundsOut where UserId =@userid;
delete from project where Id=@id;
delete from Tuser where UserNo like @projectno+'%';
end
END
GO
