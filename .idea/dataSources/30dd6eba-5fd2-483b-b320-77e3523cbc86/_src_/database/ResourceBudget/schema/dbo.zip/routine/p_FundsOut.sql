



CREATE PROCEDURE [dbo].[p_FundsOut]
	@userID	int,@budgetYear nvarchar(50)=null,@quarterNum nvarchar(50)=null
AS
BEGIN
select t.ID,t.UserID,t.PID,t.ProjectNum,t.ProjectName,t.ProjectItem,t.ProjectYear,t.QuarterNum,t.SubmitTime
	,t.FundsBudgetTotal,t.MaterialMake,t.CompanyCase,t.CourseDevelopment,t.ToolSoftware,t.ApplicationPromote,t.ResearchProve,t.ExpertConsult,t.OtherFee,t.FundsOutOrder
from 
(select FundsOut.ID,@userID as UserID,ProjectName.ID as PID,ProjectName.ProjectNum,ProjectName.ProjectName,'金额' as ProjectItem
	,Convert(nvarchar(50),convert(decimal(18,2),(FundsOut.MaterialMake+FundsOut.CompanyCase+FundsOut.CourseDevelopment+FundsOut.ToolSoftware
		+FundsOut.ApplicationPromote+FundsOut.ResearchProve+FundsOut.ExpertConsult+FundsOut.OtherFee))) as FundsBudgetTotal
	,Convert(nvarchar(50),convert(decimal(18,2),FundsOut.MaterialMake)) as MaterialMake
	,Convert(nvarchar(50),convert(decimal(18,2),FundsOut.CompanyCase)) as CompanyCase
	,Convert(nvarchar(50),convert(decimal(18,2),FundsOut.CourseDevelopment)) as CourseDevelopment
	,Convert(nvarchar(50),convert(decimal(18,2),FundsOut.ToolSoftware)) as ToolSoftware
	,Convert(nvarchar(50),convert(decimal(18,2),FundsOut.ApplicationPromote)) as ApplicationPromote
	,Convert(nvarchar(50),convert(decimal(18,2),FundsOut.ResearchProve)) as ResearchProve
	,Convert(nvarchar(50),convert(decimal(18,2),FundsOut.ExpertConsult)) as ExpertConsult
	,Convert(nvarchar(50),convert(decimal(18,2),FundsOut.OtherFee)) as OtherFee
	,@budgetYear as ProjectYear,@quarterNum as QuarterNum,FundsOut.SubmitTime,1 as FundsOutOrder
  from ProjectName left outer join FundsOut
	on ProjectName.ID= FundsOut.PID and [UserID]=@userID and FundsOut.[IsDelete]=0 and ProjectName.[IsDelete]=0 
		and FundsOut.ProjectYear=@budgetYear and FundsOut.QuarterNum=@quarterNum
  union
  select 0 as ID,@userID as UserID,ProjectName.ID,ProjectName.ProjectNum,ProjectName.ProjectName,'支出率' as ProjectItem
		,case when (t3.MoneyAmount=0 OR t3.MoneyAmount IS  null) then '-' else Convert(nvarchar(50),Convert(decimal(18,2),(t2.FundsBudgetTotal)*100/t3.MoneyAmount))+'%' end as FundsBudgetTotal
		,'-' as MaterialMake
		,'-' as CompanyCase
		,'-' as CourseDevelopment
		,'-' as ToolSoftware
		,'-' as ApplicationPromote
		,'-' as ResearchProve
		,'-' as ExpertConsult
		,'-' as OtherFee
		,@budgetYear as ProjectYear,@quarterNum as QuarterNum,null as SubmitTime,2 as FundsOutOrder
		from dbo.ProjectName left outer join(SELECT [UserID],PID,[ProjectYear],QuarterNum
					,(SUM(MaterialMake)+SUM(CompanyCase)+SUM(CourseDevelopment)+SUM(ToolSoftware)
					+SUM(ApplicationPromote)+SUM(ResearchProve)+SUM(ExpertConsult)+SUM(OtherFee)) as FundsBudgetTotal		
				FROM [dbo].[FundsOut]
				where [IsDelete]=0 and [UserID]=@userID and [ProjectYear]=@budgetYear and QuarterNum=@quarterNum
				group by [UserID],[ProjectYear],QuarterNum,PID) t2			
				on (ProjectName.ID= t2.PID )
				left outer  join (SELECT [UserID],PID,SUM(MoneyAmount) as MoneyAmount
						,[ProjectYear],QuarterNum,2 as FundsInOrder
					  FROM [dbo].[FundsIn]
					  where ([IsDelete]=0 and [UserID]=@userID and ProjectYear=@budgetYear and QuarterNum=@quarterNum)
					  group by [UserID],[ProjectYear],QuarterNum,PID) t3					  
						on (ProjectName.ID= t3.PID )
  union
  select case when t.ID IS NULL then 0 else t.ID end as ID ,TUser.UserID,
		case when t.PID IS NULL then 0 else t.PID end as PID,
		case when t.ProjectNum IS NULL then 0 else t.ProjectNum end as ProjectNum,
		case when t.ProjectName IS NULL then '合计' else t.ProjectName end as ProjectName,
		case when t.ProjectItem IS NULL then '金额' else t.ProjectItem end as ProjectItem,
		case when t.FundsBudgetTotal IS NULL then '0.00' else t.FundsBudgetTotal end as FundsBudgetTotal,
		case when t.MaterialMake IS NULL then '0.00' else t.MaterialMake end as MaterialMake,
		case when t.CompanyCase IS NULL then '0.00' else t.CompanyCase end as CompanyCase,
		case when t.CourseDevelopment IS NULL then '0.00' else t.CourseDevelopment end as CourseDevelopment,
		case when t.ToolSoftware IS NULL then '0.00' else t.ToolSoftware end as ToolSoftware,
		case when t.ApplicationPromote IS NULL then '0.00' else t.ApplicationPromote end as ApplicationPromote,
		case when t.ResearchProve IS NULL then '0.00' else t.ResearchProve end as ResearchProve,
		case when t.ExpertConsult IS NULL then '0.00' else t.ExpertConsult end as ExpertConsult,
		case when t.OtherFee IS NULL then '0.00' else t.OtherFee end as OtherFee,
		@budgetYear as ProjectYear,
		case when t.QuarterNum IS NULL then 0 else t.QuarterNum end as QuarterNum,
		NULL as SubmitTime,
		case when t.FundsOutOrder IS NULL then 1 else t.FundsOutOrder end as FundsOutOrder
  from dbo.TUser left outer join (
	  SELECT 0 as ID,[UserID],0 as PID,0 as ProjectNum,'合计' as ProjectName,'金额' as ProjectItem
		,Convert(nvarchar(50),Convert(decimal(18,2),(SUM(MaterialMake)+SUM(CompanyCase)+SUM(CourseDevelopment)+SUM(ToolSoftware)
			+SUM(ApplicationPromote)+SUM(ResearchProve)+SUM(ExpertConsult)+SUM(OtherFee)))) as FundsBudgetTotal
		,Convert(nvarchar(50),Convert(decimal(18,2),SUM(MaterialMake))) as MaterialMake
		,Convert(nvarchar(50),Convert(decimal(18,2),SUM(CompanyCase))) as CompanyCase
		,Convert(nvarchar(50),Convert(decimal(18,2),SUM(CourseDevelopment))) as CourseDevelopment
		,Convert(nvarchar(50),Convert(decimal(18,2),SUM(ToolSoftware))) as ToolSoftware
		,Convert(nvarchar(50),Convert(decimal(18,2),SUM(ApplicationPromote))) as ApplicationPromote
		,Convert(nvarchar(50),Convert(decimal(18,2),SUM(ResearchProve))) as ResearchProve
		,Convert(nvarchar(50),Convert(decimal(18,2),SUM(ExpertConsult))) as ExpertConsult
		,Convert(nvarchar(50),Convert(decimal(18,2),SUM(OtherFee))) as OtherFee
		,[ProjectYear],QuarterNum,null as SubmitTime,1 as FundsOutOrder
	  FROM [ResourceBudget].[dbo].FundsOut
	  where ([IsDelete]=0 and [UserID]=@userID and ProjectYear=@budgetYear and QuarterNum=@quarterNum)
	  group by [UserID],[ProjectYear],QuarterNum) t
	on dbo.TUser.UserID=t.UserID
	where dbo.TUser.UserID=@userID
    union
    select 0 as ID,dbo.TUser.UserID,0 as PID,0 as ProjectNum,'合计' as ProjectName,'支出率' as ProjectItem
		,case when (t3.MoneyAmount=0 OR t3.MoneyAmount IS  null) then '-' else Convert(nvarchar(50),Convert(decimal(18,2),(t2.FundsBudgetTotal)*100/t3.MoneyAmount))+'%' end as FundsBudgetTotal
		,'-' as MaterialMake
		,'-' as CompanyCase
		,'-' as CourseDevelopment
		,'-' as ToolSoftware
		,'-' as ApplicationPromote
		,'-' as ResearchProve
		,'-' as ExpertConsult
		,'-' as OtherFee
		,@budgetYear as ProjectYear,@quarterNum as QuarterNum,null as SubmitTime,2 as FundsOutOrder
		from dbo.TUser left outer join(SELECT [UserID],[ProjectYear],QuarterNum
					,(SUM(MaterialMake)+SUM(CompanyCase)+SUM(CourseDevelopment)+SUM(ToolSoftware)
					+SUM(ApplicationPromote)+SUM(ResearchProve)+SUM(ExpertConsult)+SUM(OtherFee)) as FundsBudgetTotal		
				FROM [dbo].[FundsOut]
				where [IsDelete]=0 and [UserID]=@userID and [ProjectYear]=@budgetYear and QuarterNum=@quarterNum
				group by [UserID],[ProjectYear],QuarterNum) t2			
				on (TUser.UserID= t2.UserID )
				left outer  join (SELECT [UserID],SUM(MoneyAmount) as MoneyAmount
						,[ProjectYear],QuarterNum,2 as FundsInOrder
					  FROM [dbo].[FundsIn]
					  where ([IsDelete]=0 and [UserID]=@userID and ProjectYear=@budgetYear and QuarterNum=@quarterNum)
					  group by [UserID],[ProjectYear],QuarterNum) t3					  
						on (TUser.UserID= t2.UserID )
						where TUser.UserID=@userID) t
order by t.UserID,t.ProjectNum,t.ProjectYear,t.QuarterNum,t.FundsOutOrder
END
GO
