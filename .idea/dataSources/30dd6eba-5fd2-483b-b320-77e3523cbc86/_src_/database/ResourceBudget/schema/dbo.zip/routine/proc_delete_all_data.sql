

CREATE PROCEDURE [dbo].[proc_delete_all_data] 
	@projectid int
AS
BEGIN
declare @user int;
delete from budgetimportdetail where BudgetImportId in (select id from BudgetImport where projectid>=@projectid);
delete from budgetimport where projectid>=@projectid;
delete from fundsbudget where userid in (select userid from project where id>@projectid);
delete from fundsbudgetedit where userid in (select userid from project where id>@projectid);;
delete from fundsin where userid in (select userid from project where id>@projectid);;
delete from fundsout where userid in (select userid from project where id>@projectid);;
delete from IndicatorImportDetail1 where  BudgetImportId in (select id from BudgetImport where projectid>=@projectid);
delete from IndicatorImportDetail2  where BudgetImportId in (select id from BudgetImport where projectid>=@projectid);
delete from IndicatorObjective where projectid>=@projectid;
delete from IndicatorReport where projectid>=@projectid;
delete from indicatorreportaudit where projectid>=@projectid;
delete from reportexpert where reportid in (select id from report where projectid>=@projectid);
delete from report where projectid>=@projectid;
delete from testmsg where projectid>=@projectid;
--delete from project;
--delete from tuser where userrole in (2,3,4,7);

END

GO
