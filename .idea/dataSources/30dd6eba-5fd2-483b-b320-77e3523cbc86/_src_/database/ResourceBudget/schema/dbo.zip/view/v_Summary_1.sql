CREATE VIEW dbo.v_Summary_1
AS
SELECT   dbo.TUser.UserID, dbo.TUser.UserNo, dbo.TUser.MajorName, dbo.Project.SchoolName, aa.v0, aa.v1, aa.v2, aa.v3, 
                aa.v4, aa.v5, aa.v6, aa.v7, aa.v8, aa.v9, aa.v10, aa.v11, aa.v12, aa.v13, aa.v14, aa.v15, aa.v16, aa.v17, aa.v18, aa.v19, 
                aa.v20, aa.v21, aa.v22, aa.v23, aa.v24, aa.项目年度, aa.季度
FROM      dbo.TUser LEFT OUTER JOIN
                    (SELECT   a.UserID, p.MajorName, a.PID, a.v0, b.v1, c.v2, d.v3, e.v4, f.v5, f.v6, g.v7, g.v8, h.v9, h.v10, i.v11, i.v12, 
                                     j.v13, j.v14, k.v15, k.v16, l.v17, l.v18, m.v19, m.v20, n.v21, n.v22, o.v23, o.v24, f.项目年度, f.季度
                     FROM      (SELECT   UserID, PID, 预算资金总额 AS v0
                                      FROM      dbo.v_FundsBudget
                                      WHERE   (PID = 0)) AS a INNER JOIN
                                         (SELECT   UserID, PID, 预算资金总额 AS v1
                                          FROM      dbo.v_FundsBudget AS v_FundsBudget_4
                                          WHERE   (PID = 1)) AS b ON a.UserID = b.UserID INNER JOIN
                                         (SELECT   UserID, PID, 预算资金总额 AS v2
                                          FROM      dbo.v_FundsBudget AS v_FundsBudget_3
                                          WHERE   (PID = 2)) AS c ON a.UserID = c.UserID INNER JOIN
                                         (SELECT   UserID, PID, 预算资金总额 AS v3
                                          FROM      dbo.v_FundsBudget AS v_FundsBudget_2
                                          WHERE   (PID = 3)) AS d ON a.UserID = d.UserID INNER JOIN
                                         (SELECT   UserID, PID, 预算资金总额 AS v4
                                          FROM      dbo.v_FundsBudget AS v_FundsBudget_1
                                          WHERE   (PID = 4)) AS e ON a.UserID = e.UserID INNER JOIN
                                         (SELECT   UserID, PID, 收入金额 AS v5, 到位率 AS v6, 项目年度, 季度
                                          FROM      dbo.v_FundsIn
                                          WHERE   (PID = 0)) AS f ON a.UserID = f.UserID INNER JOIN
                                         (SELECT   UserID, PID, 收入金额 AS v7, 到位率 AS v8, 项目年度, 季度
                                          FROM      dbo.v_FundsIn AS v_FundsIn_4
                                          WHERE   (PID = 1)) AS g ON a.UserID = g.UserID AND f.项目年度 = g.项目年度 AND 
                                     f.季度 = g.季度 INNER JOIN
                                         (SELECT   UserID, PID, 收入金额 AS v9, 到位率 AS v10, 项目年度, 季度
                                          FROM      dbo.v_FundsIn AS v_FundsIn_3
                                          WHERE   (PID = 2)) AS h ON a.UserID = h.UserID AND f.项目年度 = h.项目年度 AND 
                                     f.季度 = h.季度 INNER JOIN
                                         (SELECT   UserID, PID, 收入金额 AS v11, 到位率 AS v12, 项目年度, 季度
                                          FROM      dbo.v_FundsIn AS v_FundsIn_2
                                          WHERE   (PID = 3)) AS i ON a.UserID = i.UserID AND f.项目年度 = i.项目年度 AND 
                                     f.季度 = i.季度 INNER JOIN
                                         (SELECT   UserID, PID, 收入金额 AS v13, 到位率 AS v14, 项目年度, 季度
                                          FROM      dbo.v_FundsIn AS v_FundsIn_1
                                          WHERE   (PID = 4)) AS j ON a.UserID = j.UserID AND f.项目年度 = j.项目年度 AND 
                                     f.季度 = j.季度 INNER JOIN
                                         (SELECT   UserID, PID, 支出总额 AS v15, 支出率 AS v16, 预算年度, 季度
                                          FROM      dbo.v_FundsOut
                                          WHERE   (PID = 0)) AS k ON a.UserID = k.UserID AND f.项目年度 = k.预算年度 AND 
                                     f.季度 = k.季度 INNER JOIN
                                         (SELECT   UserID, PID, 支出总额 AS v17, 支出率 AS v18, 预算年度, 季度
                                          FROM      dbo.v_FundsOut AS v_FundsOut_4
                                          WHERE   (PID = 1)) AS l ON a.UserID = l.UserID AND f.项目年度 = l.预算年度 AND 
                                     f.季度 = l.季度 INNER JOIN
                                         (SELECT   UserID, PID, 支出总额 AS v19, 支出率 AS v20, 预算年度, 季度
                                          FROM      dbo.v_FundsOut AS v_FundsOut_3
                                          WHERE   (PID = 2)) AS m ON a.UserID = m.UserID AND f.项目年度 = m.预算年度 AND 
                                     f.季度 = m.季度 INNER JOIN
                                         (SELECT   UserID, PID, 支出总额 AS v21, 支出率 AS v22, 预算年度, 季度
                                          FROM      dbo.v_FundsOut AS v_FundsOut_2
                                          WHERE   (PID = 3)) AS n ON a.UserID = n.UserID AND f.项目年度 = n.预算年度 AND 
                                     f.季度 = n.季度 INNER JOIN
                                         (SELECT   UserID, PID, 支出总额 AS v23, 支出率 AS v24, 预算年度, 季度
                                          FROM      dbo.v_FundsOut AS v_FundsOut_1
                                          WHERE   (PID = 4)) AS o ON a.UserID = o.UserID AND f.项目年度 = o.预算年度 AND 
                                     f.季度 = o.季度 INNER JOIN
                                     dbo.TUser AS p ON a.UserID = p.UserID
                     WHERE   (p.IsDelete = 0)) AS aa ON dbo.TUser.UserID = aa.UserID AND dbo.TUser.IsDelete = 0 LEFT OUTER JOIN
                dbo.Project ON dbo.TUser.UserID = dbo.Project.UserID AND dbo.Project.IsDelete = 0
GO
