CREATE view [dbo].[v_FundsIn]
as
select  [UserID] ,MajorName,0 as [PID],[项目名称],[收入金额],[项目年度],[季度],[到位率]
from [v_FundsIn_2]
union 
select  [UserID],MajorName,[PID],[项目名称],[收入金额],[项目年度],[季度],[到位率]
from [v_FundsIn_1]
GO
