
CREATE view [dbo].[v_FundsOut_2]
as
 select d.UserID,d.MajorName,0 as ProjectNum,  '合计'  as 资金来源,
      sum([MaterialMake])+sum([CompanyCase])+sum([CourseDevelopment])+sum([ToolSoftware])+sum([ApplicationPromote])+sum([ResearchProve])+sum([ExpertConsult])+sum([OtherFee]) as 支出总额
      ,case  when (sum(MoneyAmount))<=0 then '-' else convert(nvarchar(50),convert(decimal(18,2),(sum([MaterialMake])+sum([CompanyCase])+sum([CourseDevelopment])+sum([ToolSoftware])+sum([ApplicationPromote])+sum([ResearchProve])+sum([ExpertConsult])+sum([OtherFee]))*1.0/(sum(MoneyAmount))*100))+'%' end as '支出率'
      ,sum([MaterialMake]) as 素材制作
      ,sum([CompanyCase]) as 企业案例收集制作
      ,sum([CourseDevelopment]) as 课程开发
      ,sum([ToolSoftware]) as 特殊工具软件制作
      ,sum([ApplicationPromote]) as 应用推广
      ,sum([ResearchProve]) as 调研论证
      ,sum([ExpertConsult]) as 专家咨询
      ,sum([OtherFee]) as 其他
       ,a.ProjectYear as 预算年度 
      ,a.QuarterNum as 季度
 from  dbo.v_UserProject d left join dbo.FundsOut a on d.UserID = a.UserID and d.ID=a.PID and a.SubmitTime is not null
      left join dbo.FundsIn c on a.UserID = c.UserID and a.PID = c.PID and a.ProjectYear = c.ProjectYear
       and a.QuarterNum = c.QuarterNum and a.IsDelete=0 and  c.IsDelete=0 and c.SubmitTime is not null
 group by d.UserID,d.MajorName,a.ProjectYear,a.QuarterNum

GO
