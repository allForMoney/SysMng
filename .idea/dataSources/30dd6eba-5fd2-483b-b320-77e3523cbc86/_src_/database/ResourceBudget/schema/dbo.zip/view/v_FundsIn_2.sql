
CREATE view [dbo].[v_FundsIn_2]
as
select c.UserID,c.MajorName,'合计' as 项目名称,sum(MoneyAmount) as 收入金额,ProjectYear as 项目年度,QuarterNum as 季度,
      case  when b.预算资金总额<=0 then '-' else convert(nvarchar(50),convert(decimal(18,2),sum(MoneyAmount)*1.0/b.预算资金总额*100))+'%' end as '到位率'
from dbo.TUser c left join dbo.FundsIn a on c.UserID =a.UserID and a.IsDelete=0 and a.SubmitTime is not null
    LEFT join dbo.v_FundsBudget b on  b.UserID =c.UserID and b.PID = 0
group by c.UserID,c.MajorName,b.预算资金总额,ProjectYear,QuarterNum

GO
