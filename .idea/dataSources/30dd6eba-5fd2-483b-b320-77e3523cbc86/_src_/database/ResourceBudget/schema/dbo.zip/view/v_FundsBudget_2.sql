
CREATE view [dbo].[v_FundsBudget_2]
as
 select c.UserID,MajorName,0 as ProjectNum,  '合计'  as 资金来源,
      sum([MaterialMake])+sum([CompanyCase])+sum([CourseDevelopment])+sum([ToolSoftware])+sum([ApplicationPromote])+sum([ResearchProve])+sum([ExpertConsult])+sum([OtherFee]) as 预算资金总额
      ,sum([MaterialMake]) as 素材制作
      ,sum([CompanyCase]) as 企业案例收集制作
      ,sum([CourseDevelopment]) as 课程开发
      ,sum([ToolSoftware]) as 特殊工具软件制作
      ,sum([ApplicationPromote]) as 应用推广
      ,sum([ResearchProve]) as 调研论证
      ,sum([ExpertConsult]) as 专家咨询
      ,sum([OtherFee]) as 其他
     ,[BudgetYear] as 预算年度 
 from  dbo.v_UserProject c left join dbo.FundsBudget a on c.UserID=a.UserID and  c.ID=a.PID
      and a.IsDelete =0 and a.SubmitTime is not null
 group by c.UserID,MajorName,[BudgetYear]

GO
