

CREATE proc [dbo].[GetCountResult2]
@myMajorName nvarchar(200)=NULL,
@myYear nvarchar(50)=NULL,
@myQuarter nvarchar(50)=NULL
 as 
 if((@myYear is not null) and @myQuarter is null)
 begin
  set @myYear = @myYear
  set @myQuarter = (select MAX(季度) from dbo.v_FundsIn_1 where (MajorName =@myMajorName) or(@myMajorName is null) )
  end  
   if((@myYear is  null) and @myQuarter is null)
 begin
  set @myYear = (select MAX(项目年度) from dbo.v_FundsIn_1 where (MajorName =@myMajorName) or(@myMajorName is null) )
  set @myQuarter = (select MAX(季度) from dbo.v_FundsIn_1 where (MajorName =@myMajorName) or(@myMajorName is null) )
  end  
  
  if(@myMajorName is null)
  begin
  SELECT 0 as [UserID],'0' as UserNo,'汇总' as MajorName ,'' as SchoolName, SUM([v0]) v0, SUM([v1]) v1, SUM([v2]) v2, SUM([v3]) v3, SUM([v4]) v4, SUM([v5]) v5, 
   case  when SUM(v0)<=0 then '-' else convert(nvarchar(50),convert(decimal(18,2),( SUM(v5))*1.0/SUM(v0)*100))+'%' end as v6, 
    SUM([v7]) v7, 
    case  when SUM(v1)<=0 then '-' else convert(nvarchar(50),convert(decimal(18,2),( SUM(v7))*1.0/SUM(v1)*100))+'%' end as v8, 
   SUM([v9]) v9,
    case  when SUM(v2)<=0 then '-' else convert(nvarchar(50),convert(decimal(18,2),( SUM(v9))*1.0/SUM(v2)*100))+'%' end as v10, 
   SUM([v11]) v11,
    case  when SUM(v3)<=0 then '-' else convert(nvarchar(50),convert(decimal(18,2),( SUM(v11))*1.0/SUM(v3)*100))+'%' end as v12, 
    SUM([v13]) v13,
    case  when SUM(v4)<=0 then '-' else convert(nvarchar(50),convert(decimal(18,2),(SUM(v13))*1.0/SUM(v4)*100))+'%' end as v14,    
     SUM([v15]) v15, 
     case  when SUM(v5)<=0 then '-' else convert(nvarchar(50),convert(decimal(18,2),(SUM(v15))*1.0/SUM(v5)*100))+'%' end as v16,
     SUM([v17]) v17,
     case  when SUM(v7)<=0 then '-' else convert(nvarchar(50),convert(decimal(18,2),(SUM(v17))*1.0/SUM(v7)*100))+'%' end as v18,
    SUM([v19]) v19,
    case  when SUM(v9)<=0 then '-' else convert(nvarchar(50),convert(decimal(18,2),(SUM(v19))*1.0/SUM(v9)*100))+'%' end as v20,  
    SUM([v21]) v21, 
    case  when SUM(v11)<=0 then '-' else convert(nvarchar(50),convert(decimal(18,2),(SUM(v21))*1.0/SUM(v11)*100))+'%' end as v22,  
   SUM([v23]) v23,
   case  when SUM(v13)<=0 then '-' else convert(nvarchar(50),convert(decimal(18,2),(SUM(v23))*1.0/SUM(v13)*100))+'%' end as v24, 
   项目年度,季度
  FROM 
  (  select TUser.UserID,TUser.UserNo,TUser.MajorName,UserInfo.SchoolName,v0,v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,v11,v12,v13,v14,v15,v16,v17,v18,v19,v20,v21,v22,v23,v24,项目年度,季度
from dbo.TUser left join
  (select a.UserID,p.MajorName,a.Pid,v0,v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,v11,v12,v13,v14,v15,v16,v17,v18,v19,v20,v21,v22,v23,v24,f.项目年度,f.季度
  from
  (select UserID,PID,预算资金总额 as v0
    FROM [ResourceBudget].[dbo].[v_FundsBudget]
    where PID = 0 and (MajorName=@myMajorName or @myMajorName is null) and (预算年度 =@myYear or @myYear is null)) a,
    ( select UserID,PID,预算资金总额 as v1
    FROM [ResourceBudget].[dbo].[v_FundsBudget]
    where PID=1 and (MajorName=@myMajorName or @myMajorName is null) and (预算年度 =@myYear or @myYear is null))  b,
    (select UserID,PID,预算资金总额 as v2
    FROM [ResourceBudget].[dbo].[v_FundsBudget]
    where PID=2 and (MajorName=@myMajorName or @myMajorName is null) and (预算年度 =@myYear or @myYear is null)) c,
    (select UserID,PID,预算资金总额 as v3
    FROM [ResourceBudget].[dbo].[v_FundsBudget]
    where PID=3 and (MajorName=@myMajorName or @myMajorName is null) and (预算年度 =@myYear or @myYear is null)) d,
    (select UserID,PID,预算资金总额 as v4
    FROM [ResourceBudget].[dbo].[v_FundsBudget]
    where PID=4 and (MajorName=@myMajorName or @myMajorName is null) and (预算年度 =@myYear or @myYear is null)) e,    
    (select UserID,PID,[收入金额] as v5,[到位率] as v6,项目年度,季度
    FROM [ResourceBudget].[dbo].[v_FundsIn]
    where PID = 0 and (MajorName=@myMajorName or @myMajorName is null) and ( 项目年度=@myYear or @myYear is null) and (季度 =@myQuarter or @myQuarter is null)) f,
    ( select UserID,PID,[收入金额] as v7,[到位率] as v8,项目年度,季度
    FROM [ResourceBudget].[dbo].[v_FundsIn]
    where PID=1 and (MajorName=@myMajorName or @myMajorName is null) and ( 项目年度=@myYear or @myYear is null) and (季度 =@myQuarter or @myQuarter is null)) g,
    (select UserID,PID,[收入金额] as v9,[到位率] as v10,项目年度,季度
    FROM [ResourceBudget].[dbo].[v_FundsIn]
    where PID=2 and (MajorName=@myMajorName or @myMajorName is null) and ( 项目年度=@myYear or @myYear is null) and (季度 =@myQuarter or @myQuarter is null)) h,
    (select UserID,PID,[收入金额] as v11,[到位率] as v12,项目年度,季度
    FROM [ResourceBudget].[dbo].[v_FundsIn]
    where PID=3 and (MajorName=@myMajorName or @myMajorName is null) and ( 项目年度=@myYear or @myYear is null) and (季度 =@myQuarter or @myQuarter is null)) i,
    (select UserID,PID,[收入金额] as v13,[到位率] as v14,项目年度,季度
    FROM [ResourceBudget].[dbo].[v_FundsIn]
    where PID=4 and (MajorName=@myMajorName or @myMajorName is null) and ( 项目年度=@myYear or @myYear is null) and (季度 =@myQuarter or @myQuarter is null)) j,
    (select UserID,PID,[支出总额] as v15,[支出率] as v16,预算年度,季度
    FROM [ResourceBudget].[dbo].[v_Fundsout]
    where PID = 0 and (MajorName=@myMajorName or @myMajorName is null) and ( 预算年度=@myYear or @myYear is null) and (季度 =@myQuarter or @myQuarter is null)) k,
    ( select UserID,PID,[支出总额] as v17,[支出率] as v18,预算年度,季度
    FROM [ResourceBudget].[dbo].[v_Fundsout]
    where PID=1 and (MajorName=@myMajorName or @myMajorName is null) and ( 预算年度=@myYear or @myYear is null) and (季度 =@myQuarter or @myQuarter is null)) l,
    (select UserID,PID,[支出总额] as v19,[支出率] as v20,预算年度,季度
    FROM [ResourceBudget].[dbo].[v_Fundsout]
    where PID=2 and (MajorName=@myMajorName or @myMajorName is null) and ( 预算年度=@myYear or @myYear is null) and (季度 =@myQuarter or @myQuarter is null)) m,
    (select UserID,PID,[支出总额] as v21,[支出率] as v22,预算年度,季度
    FROM [ResourceBudget].[dbo].[v_Fundsout]
    where PID=3 and (MajorName=@myMajorName or @myMajorName is null) and ( 预算年度=@myYear or @myYear is null) and (季度 =@myQuarter or @myQuarter is null)) n,
    (select UserID,PID,[支出总额] as v23,[支出率] as v24,预算年度,季度
    FROM [ResourceBudget].[dbo].[v_Fundsout]
    where PID=4 and (MajorName=@myMajorName or @myMajorName is null) and ( 预算年度=@myYear or @myYear is null) and (季度 =@myQuarter or @myQuarter is null)) o ,
       dbo.TUser p
    where a.UserID =b.UserID and a.UserID=c.UserID and a.UserID=d.UserID and a.UserID= e.UserID
      and a.UserID =f.UserID and a.UserID=g.UserID and a.UserID=h.UserID and a.UserID=i.UserID and a.UserID=j.UserID
      and a.UserID =k.UserID and a.UserID=l.UserID and a.UserID=m.UserID and a.UserID=n.UserID and a.UserID=o.UserID
      and a.UserID = p.UserID
       and f.项目年度 =g.项目年度 and f.季度 =g.季度  and f.项目年度 =h.项目年度 and f.季度 =h.季度
      and f.项目年度 =i.项目年度 and f.季度 =i.季度  and f.项目年度 =j.项目年度 and f.季度 =j.季度
      and f.项目年度 =k.预算年度 and f.季度 =k.季度  and f.项目年度 =l.预算年度 and f.季度 =l.季度
      and f.项目年度 =m.预算年度 and f.季度 =m.季度 and f.项目年度 =n.预算年度 and f.季度 =n.季度
      and f.项目年度 =o.预算年度 and f.季度 =o.季度 and p.IsDelete=0) aa
       on TUser.UserID = aa.UserID and TUser.IsDelete=0 left join dbo.UserInfo on TUser.UserID=UserInfo.UserID
     and UserInfo.IsDelete=0 and  TUser.UserRole=2
) b where b.项目年度 is not null and b.季度 is not null
  group by 项目年度,季度
union
  ( select TUser.UserID,TUser.UserNo,TUser.MajorName,UserInfo.SchoolName,v0,v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,v11,v12,v13,v14,v15,v16,v17,v18,v19,v20,v21,v22,v23,v24,项目年度,季度
from dbo.TUser left join
  (select a.UserID,p.MajorName,a.Pid,v0,v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,v11,v12,v13,v14,v15,v16,v17,v18,v19,v20,v21,v22,v23,v24,f.项目年度,f.季度
  from
  (select UserID,PID,预算资金总额 as v0
    FROM [ResourceBudget].[dbo].[v_FundsBudget]
    where PID = 0 and (MajorName=@myMajorName or @myMajorName is null) and (预算年度 =@myYear or @myYear is null)) a,
    ( select UserID,PID,预算资金总额 as v1
    FROM [ResourceBudget].[dbo].[v_FundsBudget]
    where PID=1 and (MajorName=@myMajorName or @myMajorName is null) and (预算年度 =@myYear or @myYear is null))  b,
    (select UserID,PID,预算资金总额 as v2
    FROM [ResourceBudget].[dbo].[v_FundsBudget]
    where PID=2 and (MajorName=@myMajorName or @myMajorName is null) and (预算年度 =@myYear or @myYear is null)) c,
    (select UserID,PID,预算资金总额 as v3
    FROM [ResourceBudget].[dbo].[v_FundsBudget]
    where PID=3 and (MajorName=@myMajorName or @myMajorName is null) and (预算年度 =@myYear or @myYear is null)) d,
    (select UserID,PID,预算资金总额 as v4
    FROM [ResourceBudget].[dbo].[v_FundsBudget]
    where PID=4 and (MajorName=@myMajorName or @myMajorName is null) and (预算年度 =@myYear or @myYear is null)) e,    
    (select UserID,PID,[收入金额] as v5,[到位率] as v6,项目年度,季度
    FROM [ResourceBudget].[dbo].[v_FundsIn]
    where PID = 0 and (MajorName=@myMajorName or @myMajorName is null) and ( 项目年度=@myYear or @myYear is null) and (季度 =@myQuarter or @myQuarter is null)) f,
    ( select UserID,PID,[收入金额] as v7,[到位率] as v8,项目年度,季度
    FROM [ResourceBudget].[dbo].[v_FundsIn]
    where PID=1 and (MajorName=@myMajorName or @myMajorName is null) and ( 项目年度=@myYear or @myYear is null) and (季度 =@myQuarter or @myQuarter is null)) g,
    (select UserID,PID,[收入金额] as v9,[到位率] as v10,项目年度,季度
    FROM [ResourceBudget].[dbo].[v_FundsIn]
    where PID=2 and (MajorName=@myMajorName or @myMajorName is null) and ( 项目年度=@myYear or @myYear is null) and (季度 =@myQuarter or @myQuarter is null)) h,
    (select UserID,PID,[收入金额] as v11,[到位率] as v12,项目年度,季度
    FROM [ResourceBudget].[dbo].[v_FundsIn]
    where PID=3 and (MajorName=@myMajorName or @myMajorName is null) and ( 项目年度=@myYear or @myYear is null) and (季度 =@myQuarter or @myQuarter is null)) i,
    (select UserID,PID,[收入金额] as v13,[到位率] as v14,项目年度,季度
    FROM [ResourceBudget].[dbo].[v_FundsIn]
    where PID=4 and (MajorName=@myMajorName or @myMajorName is null) and ( 项目年度=@myYear or @myYear is null) and (季度 =@myQuarter or @myQuarter is null)) j,
    (select UserID,PID,[支出总额] as v15,[支出率] as v16,预算年度,季度
    FROM [ResourceBudget].[dbo].[v_Fundsout]
    where PID = 0 and (MajorName=@myMajorName or @myMajorName is null) and ( 预算年度=@myYear or @myYear is null) and (季度 =@myQuarter or @myQuarter is null)) k,
    ( select UserID,PID,[支出总额] as v17,[支出率] as v18,预算年度,季度
    FROM [ResourceBudget].[dbo].[v_Fundsout]
    where PID=1 and (MajorName=@myMajorName or @myMajorName is null) and ( 预算年度=@myYear or @myYear is null) and (季度 =@myQuarter or @myQuarter is null)) l,
    (select UserID,PID,[支出总额] as v19,[支出率] as v20,预算年度,季度
    FROM [ResourceBudget].[dbo].[v_Fundsout]
    where PID=2 and (MajorName=@myMajorName or @myMajorName is null) and ( 预算年度=@myYear or @myYear is null) and (季度 =@myQuarter or @myQuarter is null)) m,
    (select UserID,PID,[支出总额] as v21,[支出率] as v22,预算年度,季度
    FROM [ResourceBudget].[dbo].[v_Fundsout]
    where PID=3 and (MajorName=@myMajorName or @myMajorName is null) and ( 预算年度=@myYear or @myYear is null) and (季度 =@myQuarter or @myQuarter is null)) n,
    (select UserID,PID,[支出总额] as v23,[支出率] as v24,预算年度,季度
    FROM [ResourceBudget].[dbo].[v_Fundsout]
    where PID=4 and (MajorName=@myMajorName or @myMajorName is null) and ( 预算年度=@myYear or @myYear is null) and (季度 =@myQuarter or @myQuarter is null)) o ,
       dbo.TUser p
    where a.UserID =b.UserID and a.UserID=c.UserID and a.UserID=d.UserID and a.UserID= e.UserID
      and a.UserID =f.UserID and a.UserID=g.UserID and a.UserID=h.UserID and a.UserID=i.UserID and a.UserID=j.UserID
      and a.UserID =k.UserID and a.UserID=l.UserID and a.UserID=m.UserID and a.UserID=n.UserID and a.UserID=o.UserID
      and a.UserID = p.UserID
       and f.项目年度 =g.项目年度 and f.季度 =g.季度  and f.项目年度 =h.项目年度 and f.季度 =h.季度
      and f.项目年度 =i.项目年度 and f.季度 =i.季度  and f.项目年度 =j.项目年度 and f.季度 =j.季度
      and f.项目年度 =k.预算年度 and f.季度 =k.季度  and f.项目年度 =l.预算年度 and f.季度 =l.季度
      and f.项目年度 =m.预算年度 and f.季度 =m.季度 and f.项目年度 =n.预算年度 and f.季度 =n.季度
      and f.项目年度 =o.预算年度 and f.季度 =o.季度 and p.IsDelete=0) aa
       on TUser.UserID = aa.UserID and TUser.IsDelete=0 left join dbo.UserInfo on TUser.UserID=UserInfo.UserID
     and UserInfo.IsDelete=0  and  TUser.UserRole=2
)
order by UserNo
end
else
  begin
  SELECT 0 as [UserID],'0' as UserNo,'汇总' as MajorName ,'' as SchoolName, SUM([v0]) v0, SUM([v1]) v1, SUM([v2]) v2, SUM([v3]) v3, SUM([v4]) v4, SUM([v5]) v5, 
   case  when SUM(v0)<=0 then '-' else convert(nvarchar(50),convert(decimal(18,2),( SUM(v5))*1.0/SUM(v0)*100))+'%' end as v6, 
    SUM([v7]) v7, 
    case  when SUM(v1)<=0 then '-' else convert(nvarchar(50),convert(decimal(18,2),( SUM(v7))*1.0/SUM(v1)*100))+'%' end as v8, 
   SUM([v9]) v9,
    case  when SUM(v2)<=0 then '-' else convert(nvarchar(50),convert(decimal(18,2),( SUM(v9))*1.0/SUM(v2)*100))+'%' end as v10, 
   SUM([v11]) v11,
    case  when SUM(v3)<=0 then '-' else convert(nvarchar(50),convert(decimal(18,2),( SUM(v11))*1.0/SUM(v3)*100))+'%' end as v12, 
    SUM([v13]) v13,
    case  when SUM(v4)<=0 then '-' else convert(nvarchar(50),convert(decimal(18,2),(SUM(v13))*1.0/SUM(v4)*100))+'%' end as v14,    
     SUM([v15]) v15, 
     case  when SUM(v5)<=0 then '-' else convert(nvarchar(50),convert(decimal(18,2),(SUM(v15))*1.0/SUM(v5)*100))+'%' end as v16,
     SUM([v17]) v17,
     case  when SUM(v7)<=0 then '-' else convert(nvarchar(50),convert(decimal(18,2),(SUM(v17))*1.0/SUM(v7)*100))+'%' end as v18,
    SUM([v19]) v19,
    case  when SUM(v9)<=0 then '-' else convert(nvarchar(50),convert(decimal(18,2),(SUM(v19))*1.0/SUM(v9)*100))+'%' end as v20,  
    SUM([v21]) v21, 
    case  when SUM(v11)<=0 then '-' else convert(nvarchar(50),convert(decimal(18,2),(SUM(v21))*1.0/SUM(v11)*100))+'%' end as v22,  
   SUM([v23]) v23,
   case  when SUM(v13)<=0 then '-' else convert(nvarchar(50),convert(decimal(18,2),(SUM(v23))*1.0/SUM(v13)*100))+'%' end as v24, 
   项目年度,季度
  FROM 
  (  select TUser.UserID,TUser.UserNo,TUser.MajorName,UserInfo.SchoolName,v0,v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,v11,v12,v13,v14,v15,v16,v17,v18,v19,v20,v21,v22,v23,v24,项目年度,季度
from dbo.TUser  join
  (select a.UserID,p.MajorName,a.Pid,v0,v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,v11,v12,v13,v14,v15,v16,v17,v18,v19,v20,v21,v22,v23,v24,f.项目年度,f.季度
  from
  (select UserID,PID,预算资金总额 as v0
    FROM [ResourceBudget].[dbo].[v_FundsBudget]
    where PID = 0 and (MajorName=@myMajorName or @myMajorName is null) and (预算年度 =@myYear or @myYear is null)) a,
    ( select UserID,PID,预算资金总额 as v1
    FROM [ResourceBudget].[dbo].[v_FundsBudget]
    where PID=1 and (MajorName=@myMajorName or @myMajorName is null) and (预算年度 =@myYear or @myYear is null))  b,
    (select UserID,PID,预算资金总额 as v2
    FROM [ResourceBudget].[dbo].[v_FundsBudget]
    where PID=2 and (MajorName=@myMajorName or @myMajorName is null) and (预算年度 =@myYear or @myYear is null)) c,
    (select UserID,PID,预算资金总额 as v3
    FROM [ResourceBudget].[dbo].[v_FundsBudget]
    where PID=3 and (MajorName=@myMajorName or @myMajorName is null) and (预算年度 =@myYear or @myYear is null)) d,
    (select UserID,PID,预算资金总额 as v4
    FROM [ResourceBudget].[dbo].[v_FundsBudget]
    where PID=4 and (MajorName=@myMajorName or @myMajorName is null) and (预算年度 =@myYear or @myYear is null)) e,    
    (select UserID,PID,[收入金额] as v5,[到位率] as v6,项目年度,季度
    FROM [ResourceBudget].[dbo].[v_FundsIn]
    where PID = 0 and (MajorName=@myMajorName or @myMajorName is null) and ( 项目年度=@myYear or @myYear is null) and (季度 =@myQuarter or @myQuarter is null)) f,
    ( select UserID,PID,[收入金额] as v7,[到位率] as v8,项目年度,季度
    FROM [ResourceBudget].[dbo].[v_FundsIn]
    where PID=1 and (MajorName=@myMajorName or @myMajorName is null) and ( 项目年度=@myYear or @myYear is null) and (季度 =@myQuarter or @myQuarter is null)) g,
    (select UserID,PID,[收入金额] as v9,[到位率] as v10,项目年度,季度
    FROM [ResourceBudget].[dbo].[v_FundsIn]
    where PID=2 and (MajorName=@myMajorName or @myMajorName is null) and ( 项目年度=@myYear or @myYear is null) and (季度 =@myQuarter or @myQuarter is null)) h,
    (select UserID,PID,[收入金额] as v11,[到位率] as v12,项目年度,季度
    FROM [ResourceBudget].[dbo].[v_FundsIn]
    where PID=3 and (MajorName=@myMajorName or @myMajorName is null) and ( 项目年度=@myYear or @myYear is null) and (季度 =@myQuarter or @myQuarter is null)) i,
    (select UserID,PID,[收入金额] as v13,[到位率] as v14,项目年度,季度
    FROM [ResourceBudget].[dbo].[v_FundsIn]
    where PID=4 and (MajorName=@myMajorName or @myMajorName is null) and ( 项目年度=@myYear or @myYear is null) and (季度 =@myQuarter or @myQuarter is null)) j,
    (select UserID,PID,[支出总额] as v15,[支出率] as v16,预算年度,季度
    FROM [ResourceBudget].[dbo].[v_Fundsout]
    where PID = 0 and (MajorName=@myMajorName or @myMajorName is null) and ( 预算年度=@myYear or @myYear is null) and (季度 =@myQuarter or @myQuarter is null)) k,
    ( select UserID,PID,[支出总额] as v17,[支出率] as v18,预算年度,季度
    FROM [ResourceBudget].[dbo].[v_Fundsout]
    where PID=1 and (MajorName=@myMajorName or @myMajorName is null) and ( 预算年度=@myYear or @myYear is null) and (季度 =@myQuarter or @myQuarter is null)) l,
    (select UserID,PID,[支出总额] as v19,[支出率] as v20,预算年度,季度
    FROM [ResourceBudget].[dbo].[v_Fundsout]
    where PID=2 and (MajorName=@myMajorName or @myMajorName is null) and ( 预算年度=@myYear or @myYear is null) and (季度 =@myQuarter or @myQuarter is null)) m,
    (select UserID,PID,[支出总额] as v21,[支出率] as v22,预算年度,季度
    FROM [ResourceBudget].[dbo].[v_Fundsout]
    where PID=3 and (MajorName=@myMajorName or @myMajorName is null) and ( 预算年度=@myYear or @myYear is null) and (季度 =@myQuarter or @myQuarter is null)) n,
    (select UserID,PID,[支出总额] as v23,[支出率] as v24,预算年度,季度
    FROM [ResourceBudget].[dbo].[v_Fundsout]
    where PID=4 and (MajorName=@myMajorName or @myMajorName is null) and ( 预算年度=@myYear or @myYear is null) and (季度 =@myQuarter or @myQuarter is null)) o ,
       dbo.TUser p
    where a.UserID =b.UserID and a.UserID=c.UserID and a.UserID=d.UserID and a.UserID= e.UserID
      and a.UserID =f.UserID and a.UserID=g.UserID and a.UserID=h.UserID and a.UserID=i.UserID and a.UserID=j.UserID
      and a.UserID =k.UserID and a.UserID=l.UserID and a.UserID=m.UserID and a.UserID=n.UserID and a.UserID=o.UserID
      and a.UserID = p.UserID
       and f.项目年度 =g.项目年度 and f.季度 =g.季度  and f.项目年度 =h.项目年度 and f.季度 =h.季度
      and f.项目年度 =i.项目年度 and f.季度 =i.季度  and f.项目年度 =j.项目年度 and f.季度 =j.季度
      and f.项目年度 =k.预算年度 and f.季度 =k.季度  and f.项目年度 =l.预算年度 and f.季度 =l.季度
      and f.项目年度 =m.预算年度 and f.季度 =m.季度 and f.项目年度 =n.预算年度 and f.季度 =n.季度
      and f.项目年度 =o.预算年度 and f.季度 =o.季度 and p.IsDelete=0) aa
       on TUser.UserID = aa.UserID and TUser.IsDelete=0 left join dbo.UserInfo on TUser.UserID=UserInfo.UserID
     and UserInfo.IsDelete=0  and  TUser.UserRole=2
) b where b.项目年度 is not null and b.季度 is not null
  group by 项目年度,季度
union
  ( select TUser.UserID,TUser.UserNo,TUser.MajorName,UserInfo.SchoolName,v0,v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,v11,v12,v13,v14,v15,v16,v17,v18,v19,v20,v21,v22,v23,v24,项目年度,季度
from dbo.TUser  join
  (select a.UserID,p.MajorName,a.Pid,v0,v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,v11,v12,v13,v14,v15,v16,v17,v18,v19,v20,v21,v22,v23,v24,f.项目年度,f.季度
  from
  (select UserID,PID,预算资金总额 as v0
    FROM [ResourceBudget].[dbo].[v_FundsBudget]
    where PID = 0 and (MajorName=@myMajorName or @myMajorName is null) and (预算年度 =@myYear or @myYear is null)) a,
    ( select UserID,PID,预算资金总额 as v1
    FROM [ResourceBudget].[dbo].[v_FundsBudget]
    where PID=1 and (MajorName=@myMajorName or @myMajorName is null) and (预算年度 =@myYear or @myYear is null))  b,
    (select UserID,PID,预算资金总额 as v2
    FROM [ResourceBudget].[dbo].[v_FundsBudget]
    where PID=2 and (MajorName=@myMajorName or @myMajorName is null) and (预算年度 =@myYear or @myYear is null)) c,
    (select UserID,PID,预算资金总额 as v3
    FROM [ResourceBudget].[dbo].[v_FundsBudget]
    where PID=3 and (MajorName=@myMajorName or @myMajorName is null) and (预算年度 =@myYear or @myYear is null)) d,
    (select UserID,PID,预算资金总额 as v4
    FROM [ResourceBudget].[dbo].[v_FundsBudget]
    where PID=4 and (MajorName=@myMajorName or @myMajorName is null) and (预算年度 =@myYear or @myYear is null)) e,    
    (select UserID,PID,[收入金额] as v5,[到位率] as v6,项目年度,季度
    FROM [ResourceBudget].[dbo].[v_FundsIn]
    where PID = 0 and (MajorName=@myMajorName or @myMajorName is null) and ( 项目年度=@myYear or @myYear is null) and (季度 =@myQuarter or @myQuarter is null)) f,
    ( select UserID,PID,[收入金额] as v7,[到位率] as v8,项目年度,季度
    FROM [ResourceBudget].[dbo].[v_FundsIn]
    where PID=1 and (MajorName=@myMajorName or @myMajorName is null) and ( 项目年度=@myYear or @myYear is null) and (季度 =@myQuarter or @myQuarter is null)) g,
    (select UserID,PID,[收入金额] as v9,[到位率] as v10,项目年度,季度
    FROM [ResourceBudget].[dbo].[v_FundsIn]
    where PID=2 and (MajorName=@myMajorName or @myMajorName is null) and ( 项目年度=@myYear or @myYear is null) and (季度 =@myQuarter or @myQuarter is null)) h,
    (select UserID,PID,[收入金额] as v11,[到位率] as v12,项目年度,季度
    FROM [ResourceBudget].[dbo].[v_FundsIn]
    where PID=3 and (MajorName=@myMajorName or @myMajorName is null) and ( 项目年度=@myYear or @myYear is null) and (季度 =@myQuarter or @myQuarter is null)) i,
    (select UserID,PID,[收入金额] as v13,[到位率] as v14,项目年度,季度
    FROM [ResourceBudget].[dbo].[v_FundsIn]
    where PID=4 and (MajorName=@myMajorName or @myMajorName is null) and ( 项目年度=@myYear or @myYear is null) and (季度 =@myQuarter or @myQuarter is null)) j,
    (select UserID,PID,[支出总额] as v15,[支出率] as v16,预算年度,季度
    FROM [ResourceBudget].[dbo].[v_Fundsout]
    where PID = 0 and (MajorName=@myMajorName or @myMajorName is null) and ( 预算年度=@myYear or @myYear is null) and (季度 =@myQuarter or @myQuarter is null)) k,
    ( select UserID,PID,[支出总额] as v17,[支出率] as v18,预算年度,季度
    FROM [ResourceBudget].[dbo].[v_Fundsout]
    where PID=1 and (MajorName=@myMajorName or @myMajorName is null) and ( 预算年度=@myYear or @myYear is null) and (季度 =@myQuarter or @myQuarter is null)) l,
    (select UserID,PID,[支出总额] as v19,[支出率] as v20,预算年度,季度
    FROM [ResourceBudget].[dbo].[v_Fundsout]
    where PID=2 and (MajorName=@myMajorName or @myMajorName is null) and ( 预算年度=@myYear or @myYear is null) and (季度 =@myQuarter or @myQuarter is null)) m,
    (select UserID,PID,[支出总额] as v21,[支出率] as v22,预算年度,季度
    FROM [ResourceBudget].[dbo].[v_Fundsout]
    where PID=3 and (MajorName=@myMajorName or @myMajorName is null) and ( 预算年度=@myYear or @myYear is null) and (季度 =@myQuarter or @myQuarter is null)) n,
    (select UserID,PID,[支出总额] as v23,[支出率] as v24,预算年度,季度
    FROM [ResourceBudget].[dbo].[v_Fundsout]
    where PID=4 and (MajorName=@myMajorName or @myMajorName is null) and ( 预算年度=@myYear or @myYear is null) and (季度 =@myQuarter or @myQuarter is null)) o ,
       dbo.TUser p
    where a.UserID =b.UserID and a.UserID=c.UserID and a.UserID=d.UserID and a.UserID= e.UserID
      and a.UserID =f.UserID and a.UserID=g.UserID and a.UserID=h.UserID and a.UserID=i.UserID and a.UserID=j.UserID
      and a.UserID =k.UserID and a.UserID=l.UserID and a.UserID=m.UserID and a.UserID=n.UserID and a.UserID=o.UserID
      and a.UserID = p.UserID
       and f.项目年度 =g.项目年度 and f.季度 =g.季度  and f.项目年度 =h.项目年度 and f.季度 =h.季度
      and f.项目年度 =i.项目年度 and f.季度 =i.季度  and f.项目年度 =j.项目年度 and f.季度 =j.季度
      and f.项目年度 =k.预算年度 and f.季度 =k.季度  and f.项目年度 =l.预算年度 and f.季度 =l.季度
      and f.项目年度 =m.预算年度 and f.季度 =m.季度 and f.项目年度 =n.预算年度 and f.季度 =n.季度
      and f.项目年度 =o.预算年度 and f.季度 =o.季度 and p.IsDelete=0) aa
       on TUser.UserID = aa.UserID and TUser.IsDelete=0 left join dbo.UserInfo on TUser.UserID=UserInfo.UserID
     and UserInfo.IsDelete=0  and  TUser.UserRole=2
)
order by UserNo
end


GO
