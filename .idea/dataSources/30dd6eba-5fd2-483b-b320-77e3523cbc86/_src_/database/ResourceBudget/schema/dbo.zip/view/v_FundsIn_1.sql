
CREATE view [dbo].[v_FundsIn_1]
as
select c.UserID,c.MajorName,c.ID as PID,c.ProjectName as 项目名称,a.MoneyAmount as 收入金额,ProjectYear as 项目年度,QuarterNum as 季度,
      case  when b.预算资金总额<=0 then '-' else convert(nvarchar(50),convert(decimal(18,2),a.MoneyAmount*1.0/b.预算资金总额*100))+'%' end as '到位率'
from dbo.v_UserProject c left join dbo.FundsIn a on c.UserID =a.UserID and c.ID= a.PID and a.SubmitTime is not null left join
      dbo.v_FundsBudget b on b.UserID =c.UserID and b.PID =c.ID and a.IsDelete=0

GO
