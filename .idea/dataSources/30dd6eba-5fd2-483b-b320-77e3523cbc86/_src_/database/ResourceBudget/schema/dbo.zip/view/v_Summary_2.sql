

/****** Script for SelectTopNRows command from SSMS  ******/

CREATE view [dbo].[v_Summary_2]
  as
SELECT 0 as [UserID],'0' as UserNo,'汇总' as MajorName ,'' as SchoolName, SUM([v0]) v0, SUM([v1]) v1, SUM([v2]) v2, SUM([v3]) v3, SUM([v4]) v4, SUM([v5]) v5, 
   case  when SUM(v0)<=0 then '-' else convert(nvarchar(50),convert(decimal(18,2),( SUM(v5))*1.0/SUM(v0)*100))+'%' end as v6, 
    SUM([v7]) v7, 
    case  when SUM(v1)<=0 then '-' else convert(nvarchar(50),convert(decimal(18,2),( SUM(v7))*1.0/SUM(v1)*100))+'%' end as v8, 
   SUM([v9]) v9,
    case  when SUM(v2)<=0 then '-' else convert(nvarchar(50),convert(decimal(18,2),( SUM(v9))*1.0/SUM(v2)*100))+'%' end as v10, 
   SUM([v11]) v11,
    case  when SUM(v3)<=0 then '-' else convert(nvarchar(50),convert(decimal(18,2),( SUM(v11))*1.0/SUM(v3)*100))+'%' end as v12, 
    SUM([v13]) v13,
    case  when SUM(v4)<=0 then '-' else convert(nvarchar(50),convert(decimal(18,2),(SUM(v13))*1.0/SUM(v4)*100))+'%' end as v14,    
     SUM([v15]) v15, 
     case  when SUM(v5)<=0 then '-' else convert(nvarchar(50),convert(decimal(18,2),(SUM(v15))*1.0/SUM(v5)*100))+'%' end as v16,
     SUM([v17]) v17,
     case  when SUM(v7)<=0 then '-' else convert(nvarchar(50),convert(decimal(18,2),(SUM(v17))*1.0/SUM(v7)*100))+'%' end as v18,
    SUM([v19]) v19,
    case  when SUM(v9)<=0 then '-' else convert(nvarchar(50),convert(decimal(18,2),(SUM(v19))*1.0/SUM(v9)*100))+'%' end as v20,  
    SUM([v21]) v21, 
    case  when SUM(v11)<=0 then '-' else convert(nvarchar(50),convert(decimal(18,2),(SUM(v21))*1.0/SUM(v11)*100))+'%' end as v22,  
   SUM([v23]) v23,
   case  when SUM(v13)<=0 then '-' else convert(nvarchar(50),convert(decimal(18,2),(SUM(v23))*1.0/SUM(v13)*100))+'%' end as v24,
   项目年度,季度
  FROM [ResourceBudget].[dbo].[v_Summary_1]
  where 项目年度 is not null and 季度 is not null
group by 项目年度,季度


GO
