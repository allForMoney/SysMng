CREATE view [dbo].[v_FundsBudget]
as
 select [UserID],MajorName,0 as  PID,[ProjectNum],[资金来源],[预算资金总额],[素材制作],[企业案例收集制作],[课程开发],
 [特殊工具软件制作],[应用推广],[调研论证],[专家咨询],[其他],[预算年度]
 from v_FundsBudget_2 
 union
  select [UserID],MajorName,[ID] as PID,[ProjectNum],[资金来源],[预算资金总额],[素材制作],[企业案例收集制作],[课程开发],
 [特殊工具软件制作],[应用推广],[调研论证],[专家咨询],[其他],[预算年度]
 from v_FundsBudget_1
GO
