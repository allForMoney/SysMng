
CREATE view [dbo].[v_FundsOut_1]
as
 select d.UserID,d.MajorName,d.ID,ProjectNum,ProjectName as 资金来源,
      [MaterialMake]+[CompanyCase]+[CourseDevelopment]+[ToolSoftware]+[ApplicationPromote]+[ResearchProve]+[ExpertConsult]+[OtherFee] as 支出总额
      ,case  when c.MoneyAmount<=0 then '-' else convert(nvarchar(50),convert(decimal(18,2),( [MaterialMake]+[CompanyCase]+[CourseDevelopment]+[ToolSoftware]+[ApplicationPromote]+[ResearchProve]+[ExpertConsult]+[OtherFee])*1.0/c.MoneyAmount*100))+'%' end as '支出率'
      ,[MaterialMake] as 素材制作
      ,[CompanyCase] as 企业案例收集制作
      ,[CourseDevelopment] as 课程开发
      ,[ToolSoftware] as 特殊工具软件制作
      ,[ApplicationPromote] as 应用推广
      ,[ResearchProve] as 调研论证
      ,[ExpertConsult] as 专家咨询
      ,[OtherFee] as 其他
      ,a.ProjectYear as 预算年度 
      ,a.QuarterNum as 季度
 from   dbo.v_UserProject d left join dbo.FundsOut a on d.UserID = a.UserID and d.ID=a.PID and a.SubmitTime is not null
      left join dbo.FundsIn c on a.UserID = c.UserID and a.PID = c.PID and a.ProjectYear = c.ProjectYear
       and a.QuarterNum = c.QuarterNum and a.IsDelete=0 and  c.IsDelete=0 and c.SubmitTime is not null

GO
