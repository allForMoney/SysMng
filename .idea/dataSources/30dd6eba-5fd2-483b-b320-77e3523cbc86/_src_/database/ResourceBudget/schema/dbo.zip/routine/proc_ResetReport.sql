
CREATE PROCEDURE proc_ResetReport
@id int 
AS
BEGIN
	update Report set Status=0, 
		FinanceAuditTime=null, SchoolAuditTime=null, ProvinceAuditTime=null,CountryAuditTime=null,
		FinanceAuditState=0, SchoolAuditState=0, ProvinceAuditState=0, CountryAuditState=0
	 	 where Id=@id;
END
GO
