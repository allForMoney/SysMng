CREATE view [dbo].[v_FundsOut]
as
 select [UserID],MajorName,0 as [PID],[ProjectNum],[资金来源],[支出总额],[支出率],[素材制作],[企业案例收集制作]
      ,[课程开发],[特殊工具软件制作],[应用推广],[调研论证],[专家咨询],[其他],[预算年度],[季度]
  FROM [ResourceBudget].[dbo].[v_Fundsout_2]
  union
   select [UserID],MajorName,ID as [PID],[ProjectNum],[资金来源],[支出总额],[支出率],[素材制作],[企业案例收集制作]
      ,[课程开发],[特殊工具软件制作],[应用推广],[调研论证],[专家咨询],[其他],[预算年度],[季度]
  FROM [ResourceBudget].[dbo].[v_Fundsout_1]
GO
