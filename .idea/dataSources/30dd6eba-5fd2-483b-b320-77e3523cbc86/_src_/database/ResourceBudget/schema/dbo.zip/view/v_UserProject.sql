create view [dbo].[v_UserProject]
as
select a.UserID,a.UserNo,a.MajorName,a.UserPassword,a.UserRole,b.ID,b.ProjectNum,b.ProjectName
from dbo.TUser a,dbo.ProjectName b
where a.IsDelete = 0 and b.IsDelete =0
GO
