



CREATE PROCEDURE [dbo].[p_FundsOut1]
	@userID	int,@budgetYear nvarchar(50)=null,@quarterNum nvarchar(50)=null
AS
BEGIN
select t.ID,t.UserID,t.PID,t.ProjectNum,t.ProjectName,t.ProjectItem,t.ProjectYear,t.QuarterNum,t.SubmitTime
	,t.FundsBudgetTotal,t.MaterialMake,t.CompanyCase,t.CourseDevelopment,t.ToolSoftware,t.ApplicationPromote,t.ResearchProve,t.ExpertConsult,t.OtherFee
from 
(select FundsOut.ID,FundsOut.UserID,ProjectName.ID as PID,ProjectName.ProjectNum,ProjectName.ProjectName,'金额' as ProjectItem
	,Convert(nvarchar(50),convert(decimal(18,2),(FundsOut.MaterialMake+FundsOut.CompanyCase+FundsOut.CourseDevelopment+FundsOut.ToolSoftware
		+FundsOut.ApplicationPromote+FundsOut.ResearchProve+FundsOut.ExpertConsult+FundsOut.OtherFee))) as FundsBudgetTotal
	,Convert(nvarchar(50),convert(decimal(18,2),FundsOut.MaterialMake)) as MaterialMake
	,Convert(nvarchar(50),convert(decimal(18,2),FundsOut.CompanyCase)) as CompanyCase
	,Convert(nvarchar(50),convert(decimal(18,2),FundsOut.CourseDevelopment)) as CourseDevelopment
	,Convert(nvarchar(50),convert(decimal(18,2),FundsOut.ToolSoftware)) as ToolSoftware
	,Convert(nvarchar(50),convert(decimal(18,2),FundsOut.ApplicationPromote)) as ApplicationPromote
	,Convert(nvarchar(50),convert(decimal(18,2),FundsOut.ResearchProve)) as ResearchProve
	,Convert(nvarchar(50),convert(decimal(18,2),FundsOut.ExpertConsult)) as ExpertConsult
	,Convert(nvarchar(50),convert(decimal(18,2),FundsOut.OtherFee)) as OtherFee
	,FundsOut.ProjectYear,FundsOut.QuarterNum,FundsOut.SubmitTime,1 as FundsOutOrder
  from ProjectName left outer join FundsOut
  on ProjectName.ID= FundsOut.PID and [UserID]=@userID and FundsOut.[IsDelete]=0 and ProjectName.[IsDelete]=0 
	and FundsOut.ProjectYear=@budgetYear and FundsOut.QuarterNum=@quarterNum
  union
  select FundsOut.ID,FundsOut.UserID,ProjectName.ID as PID,ProjectName.ProjectNum,ProjectName.ProjectName,'支出率' as ProjectItem
	,convert(nvarchar(50),convert(decimal(18,2),(FundsOut.MaterialMake+FundsOut.CompanyCase+FundsOut.CourseDevelopment+FundsOut.ToolSoftware
		+FundsOut.ApplicationPromote+FundsOut.ResearchProve+FundsOut.ExpertConsult+FundsOut.OtherFee)*100/v_FundsBudget.预算资金总额))+'%' as FundsBudgetTotal
	,convert(nvarchar(50),convert(decimal(18,2),FundsOut.MaterialMake*100/v_FundsBudget.预算资金总额))+'%' as MaterialMake
	,convert(nvarchar(50),convert(decimal(18,2),FundsOut.CompanyCase*100/v_FundsBudget.预算资金总额))+'%' as CompanyCase
	,convert(nvarchar(50),convert(decimal(18,2),FundsOut.CourseDevelopment*100/v_FundsBudget.预算资金总额))+'%' as CourseDevelopment
	,convert(nvarchar(50),convert(decimal(18,2),FundsOut.ToolSoftware*100/v_FundsBudget.预算资金总额))+'%' as ToolSoftware
	,convert(nvarchar(50),convert(decimal(18,2),FundsOut.ApplicationPromote*100/v_FundsBudget.预算资金总额))+'%' as ApplicationPromote
	,convert(nvarchar(50),convert(decimal(18,2),FundsOut.ResearchProve*100/v_FundsBudget.预算资金总额))+'%' as ResearchProve
	,convert(nvarchar(50),convert(decimal(18,2),FundsOut.ExpertConsult*100/v_FundsBudget.预算资金总额))+'%' as ExpertConsult
	,convert(nvarchar(50),convert(decimal(18,2),FundsOut.OtherFee*100/v_FundsBudget.预算资金总额))+'%' as OtherFee
	,FundsOut.ProjectYear,FundsOut.QuarterNum,FundsOut.SubmitTime,2 as FundsOutOrder
  from ProjectName left outer join FundsOut
  on ProjectName.ID= FundsOut.PID and [UserID]=@userID and FundsOut.[IsDelete]=0 and ProjectName.[IsDelete]=0 
	and FundsOut.ProjectYear=@budgetYear and FundsOut.QuarterNum=@quarterNum
	left outer join dbo.v_FundsBudget 
	on (ProjectName.ID= v_FundsBudget.PID and v_FundsBudget.[UserID]=@userID and v_FundsBudget.预算年度=@budgetYear)
  union
  select case when t.ID IS NULL then 0 else t.ID end as ID ,TUser.UserID,
		case when t.PID IS NULL then 0 else t.PID end as PID,
		case when t.ProjectNum IS NULL then 0 else t.ProjectNum end as ProjectNum,
		case when t.ProjectName IS NULL then '合计' else t.ProjectName end as ProjectName,
		case when t.ProjectItem IS NULL then '金额' else t.ProjectItem end as ProjectItem,
		case when t.FundsBudgetTotal IS NULL then '0.00' else t.FundsBudgetTotal end as FundsBudgetTotal,
		case when t.MaterialMake IS NULL then '0.00' else t.MaterialMake end as MaterialMake,
		case when t.CompanyCase IS NULL then '0.00' else t.CompanyCase end as CompanyCase,
		case when t.CourseDevelopment IS NULL then '0.00' else t.CourseDevelopment end as CourseDevelopment,
		case when t.ToolSoftware IS NULL then '0.00' else t.ToolSoftware end as ToolSoftware,
		case when t.ApplicationPromote IS NULL then '0.00' else t.ApplicationPromote end as ApplicationPromote,
		case when t.ResearchProve IS NULL then '0.00' else t.ResearchProve end as ResearchProve,
		case when t.ExpertConsult IS NULL then '0.00' else t.ExpertConsult end as ExpertConsult,
		case when t.OtherFee IS NULL then '0.00' else t.OtherFee end as OtherFee,
		@budgetYear as ProjectYear,
		case when t.QuarterNum IS NULL then 0 else t.QuarterNum end as QuarterNum,
		NULL as SubmitTime,
		case when t.FundsOutOrder IS NULL then 1 else t.FundsOutOrder end as FundsOutOrder
  from dbo.TUser left outer join (
	  SELECT 0 as ID,[UserID],0 as PID,0 as ProjectNum,'合计' as ProjectName,'金额' as ProjectItem
		,Convert(nvarchar(50),Convert(decimal(18,2),(SUM(MaterialMake)+SUM(CompanyCase)+SUM(CourseDevelopment)+SUM(ToolSoftware)
			+SUM(ApplicationPromote)+SUM(ResearchProve)+SUM(ExpertConsult)+SUM(OtherFee)))) as FundsBudgetTotal
		,Convert(nvarchar(50),Convert(decimal(18,2),SUM(MaterialMake))) as MaterialMake
		,Convert(nvarchar(50),Convert(decimal(18,2),SUM(CompanyCase))) as CompanyCase
		,Convert(nvarchar(50),Convert(decimal(18,2),SUM(CourseDevelopment))) as CourseDevelopment
		,Convert(nvarchar(50),Convert(decimal(18,2),SUM(ToolSoftware))) as ToolSoftware
		,Convert(nvarchar(50),Convert(decimal(18,2),SUM(ApplicationPromote))) as ApplicationPromote
		,Convert(nvarchar(50),Convert(decimal(18,2),SUM(ResearchProve))) as ResearchProve
		,Convert(nvarchar(50),Convert(decimal(18,2),SUM(ExpertConsult))) as ExpertConsult
		,Convert(nvarchar(50),Convert(decimal(18,2),SUM(OtherFee))) as OtherFee
		,[ProjectYear],0 as QuarterNum,1 as FundsOutOrder
	  FROM [ResourceBudget].[dbo].FundsOut
	  where ([IsDelete]=0 and [UserID]=@userID and ProjectYear=@budgetYear)
	  group by [UserID],[ProjectYear]) t
	on dbo.TUser.UserID=t.UserID
	where dbo.TUser.UserID=@userID
  union
  select case when a.ID IS NULL then 0 else a.ID end as ID ,TUser.UserID,
		case when a.PID IS NULL then 0 else a.PID end as PID,
		case when a.ProjectNum IS NULL then 0 else a.ProjectNum end as ProjectNum,
		case when a.ProjectName IS NULL then '合计' else a.ProjectName end as ProjectName,
		case when a.ProjectItem IS NULL then '支出率' else a.ProjectItem end as ProjectItem,
		case when a.FundsBudgetTotal IS NULL then '0.00%' else a.FundsBudgetTotal end as FundsBudgetTotal,
		case when a.MaterialMake IS NULL then '0.00%' else a.MaterialMake end as MaterialMake,
		case when a.CompanyCase IS NULL then '0.00%' else a.CompanyCase end as CompanyCase,
		case when a.CourseDevelopment IS NULL then '0.00%' else a.CourseDevelopment end as CourseDevelopment,
		case when a.ToolSoftware IS NULL then '0.00%' else a.ToolSoftware end as ToolSoftware,
		case when a.ApplicationPromote IS NULL then '0.00%' else a.ApplicationPromote end as ApplicationPromote,
		case when a.ResearchProve IS NULL then '0.00%' else a.ResearchProve end as ResearchProve,
		case when a.ExpertConsult IS NULL then '0.00%' else a.ExpertConsult end as ExpertConsult,
		case when a.OtherFee IS NULL then '0.00%' else a.OtherFee end as OtherFee,
		@budgetYear as ProjectYear,
		case when a.QuarterNum IS NULL then 0 else a.QuarterNum end as QuarterNum,
		NULL as SubmitTime,
		case when a.FundsOutOrder IS NULL then 2 else a.FundsOutOrder end as FundsOutOrder
	from dbo.TUser left outer join (
	  select 0 as ID,t2.UserID,0 as PID,0 as ProjectNum,'合计' as ProjectName,'支出率' as ProjectItem
		,Convert(nvarchar(50),Convert(decimal(18,2),(t2.MaterialMake+t2.CompanyCase+t2.CourseDevelopment+t2.ToolSoftware
			+t2.ApplicationPromote+t2.ResearchProve+t2.ExpertConsult+t2.OtherFee)*100/dbo.v_FundsBudget_2.预算资金总额))+'%' as FundsBudgetTotal
		,Convert(nvarchar(50),Convert(decimal(18,2),t2.MaterialMake*100/dbo.v_FundsBudget_2.预算资金总额))+'%' as MaterialMake
		,Convert(nvarchar(50),Convert(decimal(18,2),t2.CompanyCase*100/dbo.v_FundsBudget_2.预算资金总额))+'%' as CompanyCase
		,Convert(nvarchar(50),Convert(decimal(18,2),t2.CourseDevelopment*100/dbo.v_FundsBudget_2.预算资金总额))+'%' as CourseDevelopment
		,Convert(nvarchar(50),Convert(decimal(18,2),t2.ToolSoftware*100/dbo.v_FundsBudget_2.预算资金总额))+'%' as ToolSoftware
		,Convert(nvarchar(50),Convert(decimal(18,2),t2.ApplicationPromote*100/dbo.v_FundsBudget_2.预算资金总额))+'%' as ApplicationPromote
		,Convert(nvarchar(50),Convert(decimal(18,2),t2.ResearchProve*100/dbo.v_FundsBudget_2.预算资金总额))+'%' as ResearchProve
		,Convert(nvarchar(50),Convert(decimal(18,2),t2.ExpertConsult*100/dbo.v_FundsBudget_2.预算资金总额))+'%' as ExpertConsult
		,Convert(nvarchar(50),Convert(decimal(18,2),t2.OtherFee*100/dbo.v_FundsBudget_2.预算资金总额))+'%' as OtherFee
		,t2.ProjectYear,0 as QuarterNum,2 as FundsOutOrder
	  from
		(SELECT [UserID],[ProjectYear]
			,(SUM(MaterialMake)+SUM(CompanyCase)+SUM(CourseDevelopment)+SUM(ToolSoftware)
				+SUM(ApplicationPromote)+SUM(ResearchProve)+SUM(ExpertConsult)+SUM(OtherFee)) as FundsBudgetTotal
			,SUM(MaterialMake) as MaterialMake
			,SUM(CompanyCase) as CompanyCase
			,SUM(CourseDevelopment) as CourseDevelopment
			,SUM(ToolSoftware) as ToolSoftware
			,SUM(ApplicationPromote) as ApplicationPromote
			,SUM(ResearchProve) as ResearchProve
			,SUM(ExpertConsult) as ExpertConsult
			,SUM(OtherFee) as OtherFee
		FROM [dbo].[FundsOut]
		where [IsDelete]=0 and [UserID]=@userID and [ProjectYear]=@budgetYear
		group by [UserID],[ProjectYear]) t2
			inner join dbo.v_FundsBudget_2
			on (dbo.v_FundsBudget_2.UserID= t2.UserID and dbo.v_FundsBudget_2.预算年度= t2.[ProjectYear])) a
	on dbo.TUser.UserID=a.UserID 
	where TUser.UserID=1) t
order by t.ProjectNum,t.UserID,t.ProjectYear,t.QuarterNum,t.FundsOutOrder
END


GO
