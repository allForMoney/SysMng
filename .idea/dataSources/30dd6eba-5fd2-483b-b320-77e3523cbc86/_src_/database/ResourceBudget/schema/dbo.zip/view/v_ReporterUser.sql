CREATE VIEW dbo.v_ReporterUser
AS
SELECT   UserID, UserNo, MajorName, UserPassword, UserRole, Note, IsDelete, Reserve1, Reserve2, Reserve3, 
                ProvinceId
FROM      dbo.TUser
WHERE   (UserRole = 2)
GO
