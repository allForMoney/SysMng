CREATE VIEW dbo.v_UserInfo
AS
SELECT   a.UserID, a.UserNo AS 专业编号, a.MajorName AS 专业名称, b.SchoolName AS 第一主持单位, 
                b.SchoolHead AS 法定代表人, b.FinanceHead AS 财务负责人, b.FHTel AS 财务负责人联系电话, 
                b.FHQQ AS 财务负责人QQ号码, b.ProjectHead AS 项目负责人, b.PHTel AS 项目负责人联系电话, 
                b.ReportHead AS 填表人, b.RHTel AS 填表人联系电话, b.RHQQ AS 填表人QQ号码
FROM      dbo.TUser AS a INNER JOIN
                dbo.Project AS b ON a.UserID = b.UserID
WHERE   (a.IsDelete = 0) AND (b.IsDelete = 0)
GO
