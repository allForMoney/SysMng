


CREATE PROCEDURE [dbo].[p_FundsBudget1]
	@userID	int,@budgetYear nvarchar(50)=null
AS
BEGIN
	
	select PBID,UserID,PID,ProjectNum,ProjectName,FundsBudgetTotal,[MaterialMake],[CompanyCase] 
	  ,[CourseDevelopment],[ToolSoftware],[ApplicationPromote],[ResearchProve],[ExpertConsult],[OtherFee],[BudgetYear],[SubmitTime]
	from
		(select PBID,UserID,b.ID as PID,ProjectNum,ProjectName,
		[MaterialMake]+[CompanyCase]+[CourseDevelopment]+[ToolSoftware]+[ApplicationPromote]+[ResearchProve]+[ExpertConsult]+[OtherFee] as FundsBudgetTotal
		  ,[MaterialMake],[CompanyCase],[CourseDevelopment],[ToolSoftware],[ApplicationPromote],[ResearchProve]
		  ,[ExpertConsult],[OtherFee],[BudgetYear],[SubmitTime]
		from  dbo.ProjectName b left outer join dbo.FundsBudget a
			on (PID =b.ID and UserID=@userID and b.IsDelete=0 and a.IsDelete=0 and [BudgetYear]=@budgetYear)
		union 
		select case when t.PBID IS NULL then 0 else t.PBID end as PBID ,TUser.UserID,
			case when t.PID IS NULL then 0 else t.PID end as PID,
			case when t.ProjectNum IS NULL then 0 else t.ProjectNum end as ProjectNum,
			case when t.ProjectName IS NULL then '合计' else t.ProjectName end as ProjectName,
			case when t.FundsBudgetTotal IS NULL then 0 else t.FundsBudgetTotal end as FundsBudgetTotal,
			case when t.MaterialMake IS NULL then 0 else t.MaterialMake end as MaterialMake,
			case when t.CompanyCase IS NULL then 0 else t.CompanyCase end as CompanyCase,
			case when t.CourseDevelopment IS NULL then 0 else t.CourseDevelopment end as CourseDevelopment,
			case when t.ToolSoftware IS NULL then 0 else t.ToolSoftware end as ToolSoftware,
			case when t.ApplicationPromote IS NULL then 0 else t.ApplicationPromote end as ApplicationPromote,
			case when t.ResearchProve IS NULL then 0 else t.ResearchProve end as ResearchProve,
			case when t.ExpertConsult IS NULL then 0 else t.ExpertConsult end as ExpertConsult,
			case when t.OtherFee IS NULL then 0 else t.OtherFee end as OtherFee,
			t.BudgetYear,null as SubmitTime
		from dbo.TUser left outer join (
			select 0 as PBID,UserID,0 as [PID],0 as ProjectNum,  '合计'  as ProjectName,
			  sum([MaterialMake])+sum([CompanyCase])+sum([CourseDevelopment])+sum([ToolSoftware])+sum([ApplicationPromote])+sum([ResearchProve])+sum([ExpertConsult])+sum([OtherFee]) as FundsBudgetTotal
			  ,sum([MaterialMake]) as MaterialMake,sum([CompanyCase]) as CompanyCase
			  ,sum([CourseDevelopment]) as CourseDevelopment,sum([ToolSoftware]) as ToolSoftware
			  ,sum([ApplicationPromote]) as ApplicationPromote,sum([ResearchProve]) as ResearchProve
			  ,sum([ExpertConsult]) as ExpertConsult,sum([OtherFee]) as OtherFee,[BudgetYear]
			from  dbo.FundsBudget
			
			
			where (IsDelete=0 and [BudgetYear]=@budgetYear)
			
			group by UserID,[BudgetYear]) t
		on dbo.TUser.UserID=t.UserID
		where TUser.UserID=@userID) t1
	order by t1.ProjectNum
	
END


GO
