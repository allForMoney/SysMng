


CREATE PROCEDURE [dbo].[p_FundsIn1]
	@userID	int,@budgetYear nvarchar(50)=null,@quarterNum nvarchar(50)=null
AS
BEGIN
	
	select t.ID,t.UserID,t.PID,t.ProjectNum,t.ProjectName,t.ProjectItem,t.ProjectYear,t.QuarterNum,t.SubmitTime,t.MoneyAmount
		,'--' as MaterialMake,'--' as CompanyCase,'--' as CourseDevelopment,'--' as ToolSoftware,'--' as ApplicationPromote,'--' as ResearchProve,'--' as ExpertConsult,'--' as OtherFee
	from 
	(select [FundsIn].ID,[FundsIn].UserID,ProjectName.ID as PID,ProjectName.ProjectNum,ProjectName.ProjectName,'金额' as ProjectItem,Convert(nvarchar(50),convert(decimal(18,2),FundsIn.MoneyAmount)) as MoneyAmount
		,FundsIn.ProjectYear,FundsIn.QuarterNum,FundsIn.SubmitTime,1 as FundsInOrder
	  from ProjectName left outer join [FundsIn]
	  on ProjectName.ID= FundsIn.PID and [UserID]=@userID and FundsIn.[IsDelete]=0 and ProjectName.[IsDelete]=0 
		and FundsIn.ProjectYear=@budgetYear and FundsIn.QuarterNum=@quarterNum
	  union
	  select [FundsIn].ID,[FundsIn].UserID,ProjectName.ID as PID,ProjectName.ProjectNum,ProjectName.ProjectName,'到位率' as ProjectItem,convert(nvarchar(50),convert(decimal(18,2),FundsIn.MoneyAmount*100/v_FundsBudget.预算资金总额))+'%' as MoneyAmount
		,FundsIn.ProjectYear,FundsIn.QuarterNum,FundsIn.SubmitTime,2 as FundsInOrder
	  from ProjectName left outer join [FundsIn]
	  on ProjectName.ID= FundsIn.PID and [UserID]=@userID and FundsIn.[IsDelete]=0 and ProjectName.[IsDelete]=0 
		and FundsIn.ProjectYear=@budgetYear and FundsIn.QuarterNum=@quarterNum
		left outer join dbo.v_FundsBudget 
		on (ProjectName.ID= v_FundsBudget.PID and v_FundsBudget.[UserID]=@userID and v_FundsBudget.预算年度=@budgetYear)
	  union
	  select case when t.ID IS NULL then 0 else t.ID end as ID ,TUser.UserID,
			case when t.PID IS NULL then 0 else t.PID end as PID,
			case when t.ProjectNum IS NULL then 0 else t.ProjectNum end as ProjectNum,
			case when t.ProjectName IS NULL then '合计' else t.ProjectName end as ProjectName,
			case when t.ProjectItem IS NULL then '金额' else t.ProjectItem end as ProjectItem,
			case when t.MoneyAmount IS NULL then '0.00' else t.MoneyAmount end as MoneyAmount,
			@budgetYear as ProjectYear,
			case when t.QuarterNum IS NULL then 0 else t.QuarterNum end as QuarterNum,
			NULL as SubmitTime,
			case when t.FundsInOrder IS NULL then 1 else t.FundsInOrder end as FundsInOrder
	  from dbo.TUser left outer join (
		  SELECT 0 as ID,[UserID],0 as PID,0 as ProjectNum,'合计' as ProjectName,'金额' as ProjectItem,Convert(nvarchar(50),Convert(decimal(18,2),SUM(MoneyAmount))) as MoneyAmount
			,[ProjectYear],0 as QuarterNum,1 as FundsInOrder
		  FROM [ResourceBudget].[dbo].[FundsIn]
		  where ([IsDelete]=0 and [UserID]=@userID and ProjectYear=@budgetYear)
		  group by [UserID],[ProjectYear]) t
		on dbo.TUser.UserID=t.UserID
		where dbo.TUser.UserID=@userID
	  union
	  select case when a.ID IS NULL then 0 else a.ID end as ID ,TUser.UserID,
			case when a.PID IS NULL then 0 else a.PID end as PID,
			case when a.ProjectNum IS NULL then 0 else a.ProjectNum end as ProjectNum,
			case when a.ProjectName IS NULL then '合计' else a.ProjectName end as ProjectName,
			case when a.ProjectItem IS NULL then '到位率' else a.ProjectItem end as ProjectItem,
			case when a.MoneyAmount IS NULL then '0.00%' else a.MoneyAmount end as MoneyAmount,
			@budgetYear as ProjectYear,
			case when a.QuarterNum IS NULL then 0 else a.QuarterNum end as QuarterNum,
			NULL as SubmitTime,
			case when a.FundsInOrder IS NULL then 2 else a.FundsInOrder end as FundsInOrder
		from dbo.TUser left outer join (
		  select 0 as ID,t2.UserID,0 as PID,0 as ProjectNum,'合计' as ProjectName,'到位率' as ProjectItem,Convert(nvarchar(50),Convert(decimal(18,2),t2.MoneyAmountTotal*100/dbo.v_FundsBudget_2.预算资金总额))+'%' as MoneyAmount
			,t2.ProjectYear,0 as QuarterNum,2 as FundsInOrder
		  from
			(SELECT [UserID],[ProjectYear],SUM(MoneyAmount) as MoneyAmountTotal
			FROM [dbo].[FundsIn]
			where [IsDelete]=0 and [UserID]=@userID and [ProjectYear]=@budgetYear
			group by [UserID],[ProjectYear]) t2
				inner join dbo.v_FundsBudget_2
				on (dbo.v_FundsBudget_2.UserID= t2.UserID and dbo.v_FundsBudget_2.预算年度= t2.[ProjectYear])) a
		on dbo.TUser.UserID=a.UserID 
		where TUser.UserID=1) t
	order by t.ProjectNum,t.UserID,t.ProjectYear,t.QuarterNum,t.FundsInOrder
	
END


GO
